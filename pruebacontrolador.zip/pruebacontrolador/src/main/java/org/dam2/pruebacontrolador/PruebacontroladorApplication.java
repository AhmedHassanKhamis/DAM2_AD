package org.dam2.pruebacontrolador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebacontroladorApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebacontroladorApplication.class, args);
	}

}
