package org.dam2.pruebacontrolador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebacontroladorApplicationTests {

	@Test
	void contextLoads() {
	}

}
