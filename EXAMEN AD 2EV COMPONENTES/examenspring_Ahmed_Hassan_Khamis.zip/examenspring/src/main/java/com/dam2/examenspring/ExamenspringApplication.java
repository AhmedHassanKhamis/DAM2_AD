package com.dam2.examenspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenspringApplication.class, args);
	}

}
