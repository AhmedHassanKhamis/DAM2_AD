package com.dam2.examenspring.modelo;

public enum Genero {
	POP,ROCK,JAZZ,RAP;
}
