package com.dam2.examenspring.servicio;

import com.dam2.examenspring.modelo.Comentario;

public interface IComentarioServicio {
	
	public boolean insert(Comentario comentario);


}
